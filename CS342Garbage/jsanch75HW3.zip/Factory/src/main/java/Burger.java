interface Burger {
    double makeBurger();
}


