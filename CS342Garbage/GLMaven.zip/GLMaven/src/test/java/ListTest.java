import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.*;

class ListTest {

	GenericStack<Integer> s;
		
	@BeforeEach
	void init() {
		s = new GenericStack<Integer>(200);
	}
	
	@Test
	void testInitGS() {
		assertEquals("GenericStack", s.getClass().getName(), "did not initialize proper object");
	}
	
	@Test
	void testInitNode() {
		assertEquals("GenericList$Node", s.head.getClass().getName(), "did not initialize node in constructor");
		
	}
	
	@Test
	void testForNodeVal() {
		assertEquals(200, s.head.data, "value not in node");
	}
	
	@Test
	void testPopListVal() {
		
		assertEquals(200, s.pop(), "value not returned");
		
	}
	
	@Test
	void testEmptyList() {
		s.pop();
		assertNull(s.head);
	}
	
}
