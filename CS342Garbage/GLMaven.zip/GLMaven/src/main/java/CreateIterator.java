import java.util.Iterator;

public interface CreateIterator<I> {

	public Iterator<I> createIterator();
}
