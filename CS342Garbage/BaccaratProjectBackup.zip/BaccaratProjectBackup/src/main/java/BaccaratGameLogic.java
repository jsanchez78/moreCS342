import java.util.ArrayList;

public class BaccaratGameLogic {

    public String whoWon(ArrayList<Card> hand1, ArrayList<Card> hand2){
        String a = null;
        return a;
    }
    public int handTotal(ArrayList<Card> hand){

        return 0;
    }
    public boolean evaluateBankerDraw(ArrayList<Card> hand, Card playerCard){
        return true;

    }
    public boolean evaluatePlayerDraw(ArrayList<Card> hand){

        return true;
    }

}
