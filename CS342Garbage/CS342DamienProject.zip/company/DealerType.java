package com.company;

interface DealerType {
    public Dealer createDealer();
}

