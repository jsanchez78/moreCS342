package com.company;
import java.io.*;
import java.util.ArrayList;
interface Dealer{
    public ArrayList<Card> dealHand();
}
